#define MyAppName "Sistema de Automação"
#define MyAppVersion "1.1.5"
#define MyAppPublisher "Flávio Galera"
#define MyAppExeName "SistemaAutomacao.exe"

[Setup]
AppId={{B8A9F28D-9B75-4D47-AFA2-3A1E1B9D4C51}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Sistema de Automação
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=dist_instalador
OutputBaseFilename=SistemaAutomacao_1.1.5_Windows_x64
SetupIconFile=assets\sistema-automacao.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
WizardStyle=modern
Compression=lzma2
SolidCompression=yes
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "Criar atalho na Área de Trabalho"; GroupDescription: "Atalhos adicionais:"; Flags: unchecked

[Files]
Source: "dist\SistemaAutomacao\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Abrir {#MyAppName}"; Flags: postinstall nowait skipifsilent

; Importante: o desinstalador remove somente os arquivos instalados em {app}.
; Não apagar %APPDATA%\SistemaAutomacao: ali ficam o cofre e o histórico do usuário.
