@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ================================================
echo   SISTEMA DE AUTOMACAO - COMPILACAO WINDOWS
echo   Versao 1.1.5 - Windows 10/11 x64
echo ================================================
echo.

where py >nul 2>nul
if errorlevel 1 (
    echo ERRO: Python Launcher nao encontrado.
    echo Instale Python 3.14 x64 e marque a opcao Python Launcher.
    pause
    exit /b 1
)

if not exist ".venv-build-win\Scripts\python.exe" (
    echo Criando ambiente isolado de compilacao...
    py -3.14 -m venv .venv-build-win
    if errorlevel 1 goto :erro
)

call ".venv-build-win\Scripts\activate.bat"
if errorlevel 1 goto :erro

echo Atualizando ferramentas...
python -m pip install --upgrade pip
if errorlevel 1 goto :erro

echo Instalando dependencias...
python -m pip install -r requirements-windows.txt
if errorlevel 1 goto :erro

echo Verificando sintaxe do programa...
python -m py_compile assistente_gui_v2.py
if errorlevel 1 goto :erro

echo Gerando aplicativo Windows sem terminal...
python -m PyInstaller --noconfirm --clean --distpath dist --workpath build SistemaAutomacao.spec
if errorlevel 1 goto :erro

echo.
echo Aplicativo compilado em: dist\SistemaAutomacao\SistemaAutomacao.exe

echo Procurando o compilador do Inno Setup...
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"

if exist "%ISCC%" (
    echo Criando instalador grafico EXE...
    "%ISCC%" instalador_windows.iss
    if errorlevel 1 goto :erro
    echo.
    echo INSTALADOR GERADO EM:
    echo dist_instalador\SistemaAutomacao_1.1.5_Windows_x64.exe
) else (
    echo.
    echo O aplicativo foi compilado, mas o Inno Setup 6 nao foi encontrado.
    echo Instale o Inno Setup 6 e execute novamente este arquivo .bat.
)

echo.
echo Processo concluido.
pause
exit /b 0

:erro
echo.
echo ERRO durante a compilacao. Leia a mensagem acima.
pause
exit /b 1
