# PyInstaller spec - Sistema de Automação 1.1.5 (Windows x64)
from pathlib import Path
from PyInstaller.utils.hooks import collect_all

ROOT = Path(SPECPATH)
datas = []
binaries = []
hiddenimports = [
    "matplotlib.backends.backend_tkagg",
    "matplotlib.backends.backend_agg",
    "openpyxl",
    "pandas",
    "cryptography.fernet",
    "cryptography.hazmat.primitives.kdf.pbkdf2",
]

# Reúne recursos e módulos carregados dinamicamente pelas bibliotecas.
for package in ("numpy", "pandas", "openpyxl", "matplotlib", "cryptography"):
    package_datas, package_binaries, package_hiddenimports = collect_all(package)
    datas += package_datas
    binaries += package_binaries
    hiddenimports += package_hiddenimports

a = Analysis(
    [str(ROOT / "assistente_gui_v2.py")],
    pathex=[str(ROOT)],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="SistemaAutomacao",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    icon=str(ROOT / "assets" / "sistema-automacao.ico"),
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="SistemaAutomacao",
)
